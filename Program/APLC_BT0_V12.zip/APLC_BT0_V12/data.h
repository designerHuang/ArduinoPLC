int num;
int runNum;
int locationNum;
int templateNum;
unsigned long timer;

float xPos;
float yPos;
float zPos;
int coordA;
int coordB;
int coordC;
int coordD;
int coordE;
int coordF;

/*坐标*/
long positions[2];
long A;
long B;
long C;
long D;
long E;
long F;
