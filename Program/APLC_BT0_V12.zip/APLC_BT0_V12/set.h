void setCoord() {
  
}

void setSpeed() {
  
}

void setLaser() {
  
}
